/**
 * This package provides utility classes for finding type information for generic types.
 *  
 * @author Inderjeet Singh, Joel Leitch
 */
package utils.com.google.gson.reflect;