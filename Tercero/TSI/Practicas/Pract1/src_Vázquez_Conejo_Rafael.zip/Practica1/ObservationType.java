package Practica1;

/*
 Nos permite definir ante que objeto nos encontramos en el mapa
 */

public enum ObservationType {
	MURO, GEMA, ESCORPION, SALIDA, VACIO, JUGADOR
}
